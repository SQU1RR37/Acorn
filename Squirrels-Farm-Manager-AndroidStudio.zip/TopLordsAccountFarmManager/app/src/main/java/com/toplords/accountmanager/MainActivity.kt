package com.toplords.accountmanager

import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private const val MAX_ACCOUNTS = 100
private const val KEY_ALIAS = "toplords_account_vault_v1"

 data class GameAccount(
    val id: String,
    val username: String,
    val email: String,
    val password: String,
    val server: String,
    val status: String,
    val created: String,
    val lastLogin: String,
    val notes: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { AccountManagerApp() } }
    }
}

private class EncryptedVault(private val context: android.content.Context) {
    private val file = File(context.filesDir, "accounts.vault")
    private val gson = Gson()

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    fun load(): MutableList<GameAccount> {
        if (!file.exists()) return mutableListOf()
        return try {
            val bytes = file.readBytes()
            if (bytes.size < 13) return mutableListOf()
            val iv = bytes.copyOfRange(0, 12)
            val encrypted = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val json = cipher.doFinal(encrypted).toString(Charsets.UTF_8)
            val type = object : TypeToken<MutableList<GameAccount>>() {}.type
            gson.fromJson<MutableList<GameAccount>>(json, type) ?: mutableListOf()
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(accounts: List<GameAccount>) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(gson.toJson(accounts).toByteArray(Charsets.UTF_8))
        file.writeBytes(cipher.iv + encrypted)
    }
}

@Composable
private fun AccountManagerApp() {
    val context = LocalContext.current
    val vault = remember { EncryptedVault(context) }
    var accounts by remember { mutableStateOf(vault.load()) }
    var search by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf<GameAccount?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<GameAccount?>(null) }
    var message by remember { mutableStateOf("") }

    fun persist(next: List<GameAccount>) {
        accounts = next.toMutableList()
        vault.save(accounts)
    }

    val filtered = accounts.filter {
        listOf(it.username, it.email, it.server, it.status).any { field -> field.contains(search, true) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("TOP LORDS • ACCOUNT MANAGER") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editor = null; showEditor = true },
                containerColor = MaterialTheme.colorScheme.primary) { Icon(Icons.Default.Add, "Add account") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("ACCOUNTS", "${accounts.size}/$MAX_ACCOUNTS", Modifier.weight(1f))
                StatCard("ACTIVE", accounts.count { it.status == "Active" }.toString(), Modifier.weight(1f))
                StatCard("SERVERS", accounts.map { it.server }.distinct().size.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, label = { Text("Search username, email, server, status") },
                leadingIcon = { Icon(Icons.Default.Search, null) })
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("ACCOUNT REGISTER", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text("${filtered.size} shown", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (accounts.isEmpty()) "No accounts yet. Tap + to add your first account." else "No matching accounts.", color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                    items(filtered, key = { it.id }) { account ->
                        AccountCard(account,
                            onEdit = { editor = account; showEditor = true },
                            onDelete = { deleteTarget = account })
                    }
                }
            }
        }
    }

    if (showEditor) {
        AccountEditor(account = editor, onDismiss = { showEditor = false }, onSave = { item ->
            val existing = accounts.any { it.id == item.id }
            if (!existing && accounts.size >= MAX_ACCOUNTS) message = "Limit reached: this vault supports up to 100 accounts."
            else {
                persist(if (existing) accounts.map { if (it.id == item.id) item else it } else accounts + item)
                showEditor = false
            }
        })
    }

    deleteTarget?.let { target ->
        AlertDialog(onDismissRequest = { deleteTarget = null },
            title = { Text("Delete account?") },
            text = { Text("Remove ${target.username} from this device? This cannot be undone.") },
            confirmButton = { TextButton(onClick = { persist(accounts.filterNot { it.id == target.id }); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } })
    }
    if (message.isNotBlank()) AlertDialog(onDismissRequest = { message = "" }, title = { Text("Account limit") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { message = "" }) { Text("OK") } })
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AccountCard(account: GameAccount, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(account.username, style = MaterialTheme.typography.titleMedium)
                    Text("Server ${account.server}  •  ${account.status}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error) }
            }
            Text(account.email.ifBlank { "No email recorded" }, style = MaterialTheme.typography.bodyMedium)
            Text("Created: ${account.created.ifBlank { "Not set" }}   •   Last login: ${account.lastLogin.ifBlank { "Not set" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (account.notes.isNotBlank()) Text("Notes: ${account.notes}", style = MaterialTheme.typography.bodySmall, maxLines = 2)
        }
    }
}

@Composable
private fun AccountEditor(account: GameAccount?, onDismiss: () -> Unit, onSave: (GameAccount) -> Unit) {
    var username by remember { mutableStateOf(account?.username ?: "") }
    var email by remember { mutableStateOf(account?.email ?: "") }
    var password by remember { mutableStateOf(account?.password ?: "") }
    var server by remember { mutableStateOf(account?.server ?: "") }
    var status by remember { mutableStateOf(account?.status ?: "Active") }
    var created by remember { mutableStateOf(account?.created ?: "") }
    var lastLogin by remember { mutableStateOf(account?.lastLogin ?: "") }
    var notes by remember { mutableStateOf(account?.notes ?: "") }
    var reveal by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (account == null) "Add account" else "Edit account") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(username, { username = it }, label = { Text("Username *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(email, { email = it }, label = { Text("Login email") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Hide" else "Show") } })
                OutlinedTextField(server, { server = it }, label = { Text("Server number") }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("Status", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Active", "Inactive", "Recovery").forEach { value -> FilterChip(selected = status == value, onClick = { status = value }, label = { Text(value) }) }
                }
                OutlinedTextField(created, { created = it }, label = { Text("Creation date (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(lastLogin, { lastLogin = it }, label = { Text("Last login (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes / recovery hints (never store recovery codes)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = {
            if (username.isBlank()) error = "Username is required."
            else onSave(GameAccount(account?.id ?: java.util.UUID.randomUUID().toString(), username.trim(), email.trim(), password, server.trim(), status, created.trim(), lastLogin.trim(), notes.trim()))
        }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
